package control;

import java.io.IOException;

public class ProgramaServidor {
	public static void main(String[] args) throws IOException {
		new Servidor();
	}
}
